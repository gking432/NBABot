"""
Dashboard Templates.
CURSOR: Build this file. See CURSOR_DASHBOARD_SPEC.md for complete requirements.
This should return a single HTML string with embedded CSS and JS.
"""


def render_dashboard() -> str:
    """Return the full dashboard HTML. Cursor: implement this."""
    return """
    <html><body>
    <h1>NBA Trading Bot Dashboard</h1>
    <p>Cursor: Replace this with the full dashboard from CURSOR_DASHBOARD_SPEC.md</p>
    <p>API endpoints available at /api/status, /api/trades, /api/signals, etc.</p>
    </body></html>
    """
