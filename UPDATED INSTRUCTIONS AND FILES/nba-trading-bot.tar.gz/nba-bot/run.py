"""Entry point for the NBA Trading Bot."""
import logging
import sys
import os
import threading

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.config import LOG_LEVEL, DASHBOARD_PORT
from core.bot import TradingBot


def setup_logging():
    os.makedirs("logs", exist_ok=True)
    logging.basicConfig(
        level=getattr(logging, LOG_LEVEL, logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler("logs/bot.log"),
        ],
    )


def start_dashboard(bot):
    """Start the dashboard in a background thread."""
    try:
        from dashboard.app import create_app
        import uvicorn
        app = create_app(bot)
        uvicorn.run(app, host="0.0.0.0", port=DASHBOARD_PORT, log_level="warning")
    except Exception as e:
        logging.error(f"Dashboard failed to start: {e}")


def main():
    setup_logging()
    bot = TradingBot()

    # Start dashboard in background thread
    dash_thread = threading.Thread(target=start_dashboard, args=(bot,), daemon=True)
    dash_thread.start()
    logging.info(f"Dashboard starting at http://localhost:{DASHBOARD_PORT}")

    # Run the bot (blocking)
    bot.run()


if __name__ == "__main__":
    main()
