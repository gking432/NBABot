"""
Risk Manager.
Enforces all position limits, daily/weekly loss limits, and global kill switches.
"""
import logging
from typing import Dict
from datetime import datetime, timedelta

from core.models import Strategy, EntrySignal
from core.config import (
    DAILY_LOSS_LIMIT_PCT, WEEKLY_LOSS_LIMIT_PCT, GLOBAL_HARD_FLOOR_PCT,
    CONS_MAX_CONCURRENT_POSITIONS, TIER_MAX_CONCURRENT_POSITIONS,
    HF_MAX_CONCURRENT_POSITIONS,
    INITIAL_BANKROLL_CENTS,
)

logger = logging.getLogger(__name__)


class RiskManager:
    """
    Enforces all risk limits.
    Every entry signal passes through here before execution.
    """

    def __init__(self, position_manager):
        self.pm = position_manager

        # Track daily starting balances
        self._daily_start: Dict[Strategy, int] = {}
        self._weekly_start: Dict[Strategy, int] = {}
        self._day_of_record: int = -1
        self._week_of_record: int = -1

        # Kill switch states
        self.strategy_paused: Dict[Strategy, bool] = {
            Strategy.CONSERVATIVE: False,
            Strategy.TIERED: False,
            Strategy.HEAVY_FAVORITE: False,
        }
        self.global_pause = False

        # Max concurrent positions per strategy
        self.max_concurrent = {
            Strategy.CONSERVATIVE: CONS_MAX_CONCURRENT_POSITIONS,
            Strategy.TIERED: TIER_MAX_CONCURRENT_POSITIONS,
            Strategy.HEAVY_FAVORITE: HF_MAX_CONCURRENT_POSITIONS,
        }

    def check_signal(self, signal: EntrySignal) -> tuple:
        """
        Check if a signal is allowed by risk rules.
        Returns (allowed: bool, reason: str).
        """
        strategy = signal.strategy

        # Global pause
        if self.global_pause:
            return False, "Global pause active — bankroll below hard floor"

        # Strategy paused
        if self.strategy_paused.get(strategy, False):
            return False, f"{strategy.value} paused due to loss limit"

        # Concurrent position limit
        current_count = self.pm.count_positions(strategy)
        max_allowed = self.max_concurrent.get(strategy, 2)
        if current_count >= max_allowed:
            return False, f"{strategy.value} at max positions ({current_count}/{max_allowed})"

        # Check if this is a new position or adding to existing
        if signal.entry_number == 1 and current_count >= max_allowed:
            return False, f"No room for new {strategy.value} position"

        return True, "OK"

    def update_limits(self):
        """
        Check daily/weekly loss limits and activate kill switches.
        Call this on every main loop iteration.
        """
        now = datetime.utcnow()

        # Record daily starting balances
        if now.day != self._day_of_record:
            self._day_of_record = now.day
            for strategy in Strategy:
                self._daily_start[strategy] = self.pm.bankrolls.get(strategy, 0)
            # Reset daily pauses
            for strategy in Strategy:
                if self.strategy_paused.get(strategy):
                    logger.info(f"New day — resetting {strategy.value} pause")
                    self.strategy_paused[strategy] = False

        # Record weekly starting balances
        if now.isocalendar()[1] != self._week_of_record:
            self._week_of_record = now.isocalendar()[1]
            for strategy in Strategy:
                self._weekly_start[strategy] = self.pm.bankrolls.get(strategy, 0)

        # Check daily loss limits per strategy
        for strategy in Strategy:
            daily_start = self._daily_start.get(strategy, 0)
            if daily_start <= 0:
                continue
            current = self.pm.bankrolls.get(strategy, 0)
            daily_loss_pct = (daily_start - current) / daily_start

            if daily_loss_pct >= DAILY_LOSS_LIMIT_PCT:
                if not self.strategy_paused.get(strategy):
                    self.strategy_paused[strategy] = True
                    logger.warning(
                        f"KILL SWITCH: {strategy.value} paused — daily loss "
                        f"{daily_loss_pct:.1%} exceeds {DAILY_LOSS_LIMIT_PCT:.0%} limit"
                    )

        # Check weekly loss limits
        for strategy in Strategy:
            weekly_start = self._weekly_start.get(strategy, 0)
            if weekly_start <= 0:
                continue
            current = self.pm.bankrolls.get(strategy, 0)
            weekly_loss_pct = (weekly_start - current) / weekly_start

            if weekly_loss_pct >= WEEKLY_LOSS_LIMIT_PCT:
                if not self.strategy_paused.get(strategy):
                    self.strategy_paused[strategy] = True
                    logger.warning(
                        f"KILL SWITCH: {strategy.value} paused — weekly loss "
                        f"{weekly_loss_pct:.1%} exceeds {WEEKLY_LOSS_LIMIT_PCT:.0%} limit"
                    )

        # Check global hard floor
        total = sum(self.pm.bankrolls.values())
        floor = int(INITIAL_BANKROLL_CENTS * GLOBAL_HARD_FLOOR_PCT)
        if total < floor and not self.global_pause:
            self.global_pause = True
            logger.critical(
                f"GLOBAL KILL SWITCH: Total bankroll {total}¢ below "
                f"hard floor {floor}¢ ({GLOBAL_HARD_FLOOR_PCT:.0%} of start). "
                f"ALL TRADING PAUSED."
            )

    def get_status(self) -> dict:
        """Get current risk status for dashboard."""
        return {
            "global_pause": self.global_pause,
            "strategy_pauses": {s.value: v for s, v in self.strategy_paused.items()},
            "bankrolls": {s.value: v for s, v in self.pm.bankrolls.items()},
            "total_bankroll": sum(self.pm.bankrolls.values()),
            "positions_count": {
                s.value: self.pm.count_positions(s) for s in Strategy
            },
        }
