"""
Strategy 2: Tiered
Close-spread games, team falls behind early, buy the dip, ride the comeback.
Multi-entry averaging down. House money exit system. Time-based defensive management.
"""
import logging
from typing import Optional
from datetime import datetime

from core.models import (
    LiveGameState, EntrySignal, Position, Strategy, GameMode, GameStatus
)
from core.config import (
    TIER_MIN_SPREAD, TIER_MAX_SPREAD,
    TIER_MIN_DEFICIT_VS_SPREAD, TIER_MIN_PRICE_DROP_PCT,
    TIER_MAX_ENTRY_PRICE_CENTS, TIER_MIN_BOOK_DEPTH,
    TIER_MAX_ENTRY_QUARTER,
    TIER_ENTRY2_MIN_ADDITIONAL_DROP_PCT, TIER_ENTRY2_MIN_ADDITIONAL_DEFICIT,
    TIER_ENTRY2_MIN_TIME_LEFT_Q2_SEC,
    TIER_ENTRY34_MIN_ADDITIONAL_DROP_PCT, TIER_ENTRY4_MIN_TIME_LEFT_Q2_SEC,
    TIER_GAME_BUDGET_PCT, TIER_NUCLEAR_BUDGET_PCT, TIER_MAX_PER_GAME_PCT,
    TIER_CAPITAL_RECOVERY_MULT, TIER_CAPITAL_RECOVERY_SELL_PCT,
    TIER_HOUSE_MONEY_1_MULT, TIER_HOUSE_MONEY_1_SELL_PCT,
    TIER_HOUSE_MONEY_2_MULT, TIER_HOUSE_MONEY_2_SELL_PCT,
    TIER_LATE_GAME_PRICE_CENTS, TIER_LATE_GAME_SELL_PCT,
    TIER_TRAILING_STOP_PCT, TIER_DEFENSIVE_HARD_FLOOR_PCT,
)
from strategies.base import BaseStrategy

logger = logging.getLogger(__name__)


class TieredStrategy(BaseStrategy):
    """
    Multi-entry price-drop strategy for close-spread games.
    Up to 4 entries per game. House money exit system.
    Time-based offensive/neutral/defensive modes.
    """

    def __init__(self, positions: dict, bankroll_cents: int):
        super().__init__(Strategy.TIERED, positions)
        self.bankroll_cents = bankroll_cents

    def check_entry(self, state: LiveGameState) -> Optional[EntrySignal]:
        """
        Check entry conditions.
        Handles Entry 1 (new position) and Entry 2-4 (averaging down).
        """
        if not self.is_game_tradeable(state):
            return None

        existing = self.get_position_for_game(state.game_id_espn)

        if existing:
            return self._check_additional_entry(state, existing)
        else:
            return self._check_first_entry(state)

    def _check_first_entry(self, state: LiveGameState) -> Optional[EntrySignal]:
        """Check conditions for Entry 1 (new position)."""

        # 1. Quarter must be 1 or 2
        if state.quarter > TIER_MAX_ENTRY_QUARTER:
            return None

        # 2. Pre-game spread between 1 and 7
        if not (TIER_MIN_SPREAD <= state.opening_spread <= TIER_MAX_SPREAD):
            return None

        # 3. Deficit vs spread >= 10
        if state.deficit_vs_spread < TIER_MIN_DEFICIT_VS_SPREAD:
            return None

        # 4. Price dropped >= 25% from tipoff
        if state.price_drop_from_tipoff < TIER_MIN_PRICE_DROP_PCT:
            return None

        # 5. Kalshi ask <= 40¢
        ask_price = state.kalshi_yes_ask
        if ask_price is None or ask_price > TIER_MAX_ENTRY_PRICE_CENTS:
            return None

        # 6. Book depth >= 50
        if state.kalshi_book_depth < TIER_MIN_BOOK_DEPTH:
            return None

        # ─── SIZING: 50% of game budget ───
        game_budget = int(self.bankroll_cents * TIER_GAME_BUDGET_PCT)
        entry1_budget = game_budget // 2
        shares = entry1_budget // ask_price

        if shares < 1:
            return None

        confidence = 65
        if state.price_drop_from_tipoff >= 0.40:
            confidence = 75
        if state.deficit_vs_spread >= 15:
            confidence = 80

        reason = (
            f"Tiered Entry 1: spread={state.opening_spread}, "
            f"deficit={state.deficit_vs_spread:.1f}, "
            f"price_drop={state.price_drop_from_tipoff:.0%}, "
            f"price={ask_price}¢, "
            f"Q{state.quarter} {state.time_remaining_seconds // 60}:{state.time_remaining_seconds % 60:02d}"
        )

        return self.build_signal(
            state=state,
            entry_number=1,
            suggested_shares=shares,
            suggested_cost_cents=shares * ask_price,
            budget_source="GAME_BUDGET",
            confidence=confidence,
            reason=reason,
        )

    def _check_additional_entry(
        self, state: LiveGameState, position: Position
    ) -> Optional[EntrySignal]:
        """Check conditions for Entry 2, 3, or 4 (averaging down)."""

        next_entry = position.entry_count + 1
        if next_entry > 4:
            return None

        # Must still be Q1 or Q2
        if state.quarter > TIER_MAX_ENTRY_QUARTER:
            return None

        # Time requirements
        if state.quarter == 2:
            if next_entry == 2 and state.time_remaining_seconds < TIER_ENTRY2_MIN_TIME_LEFT_Q2_SEC:
                return None
            if next_entry >= 4 and state.time_remaining_seconds < TIER_ENTRY4_MIN_TIME_LEFT_Q2_SEC:
                return None

        # Price must have dropped further from last entry
        last_entry = position.entries[-1] if position.entries else None
        if not last_entry:
            return None

        ask_price = state.kalshi_yes_ask
        if ask_price is None:
            return None

        last_price = last_entry.price_cents
        if last_price <= 0:
            return None

        price_drop_since_last = (last_price - ask_price) / last_price
        min_drop = (TIER_ENTRY2_MIN_ADDITIONAL_DROP_PCT
                    if next_entry == 2
                    else TIER_ENTRY34_MIN_ADDITIONAL_DROP_PCT)

        if price_drop_since_last < min_drop:
            return None

        # Entry 2 requires deficit to have grown by 8+
        if next_entry == 2:
            # Estimate deficit at Entry 1 from the entry record
            deficit_growth = state.deficit_vs_spread - TIER_MIN_DEFICIT_VS_SPREAD
            if deficit_growth < TIER_ENTRY2_MIN_ADDITIONAL_DEFICIT:
                return None

        # No book depth check relaxation for additional entries
        if state.kalshi_book_depth < TIER_MIN_BOOK_DEPTH:
            return None

        # ─── SIZING ───
        if next_entry == 2:
            # Second half of game budget
            game_budget = int(self.bankroll_cents * TIER_GAME_BUDGET_PCT)
            budget = game_budget // 2
            budget_source = "GAME_BUDGET"
        else:
            # Nuclear reserve for Entry 3 and 4
            nuclear_budget = int(self.bankroll_cents * TIER_NUCLEAR_BUDGET_PCT)
            if next_entry == 3:
                budget = nuclear_budget // 2  # Split nuclear 50/50 for 3 and 4
            else:
                budget = nuclear_budget // 2
            budget_source = "NUCLEAR_RESERVE"

            # Check total allocation isn't exceeded
            max_total = int(self.bankroll_cents * TIER_MAX_PER_GAME_PCT)
            already_used = position.game_budget_used_cents + position.nuclear_budget_used_cents
            if already_used + budget > max_total:
                budget = max_total - already_used
                if budget <= 0:
                    return None

        shares = budget // ask_price
        if shares < 1:
            return None

        confidence = 70 + (next_entry * 5)  # Higher entry number = more conviction

        reason = (
            f"Tiered Entry {next_entry}: price dropped {price_drop_since_last:.0%} since Entry {next_entry - 1}, "
            f"deficit={state.deficit_vs_spread:.1f}, price={ask_price}¢, "
            f"Q{state.quarter} {state.time_remaining_seconds // 60}:{state.time_remaining_seconds % 60:02d}"
        )

        return self.build_signal(
            state=state,
            entry_number=next_entry,
            suggested_shares=shares,
            suggested_cost_cents=shares * ask_price,
            budget_source=budget_source,
            confidence=confidence,
            reason=reason,
        )

    def check_exit(self, state: LiveGameState, position: Position) -> Optional[dict]:
        """
        Check all exit conditions for a tiered position.
        Logic depends on game mode and whether capital has been recovered.
        """
        current_price = state.kalshi_yes_ask or state.kalshi_last_price
        if current_price is None or current_price == 0:
            return None

        if position.shares_remaining <= 0:
            return None

        avg_cost = position.avg_cost_cents
        if avg_cost == 0:
            return None

        # Update highest price for trailing stop
        position.update_highest_price(current_price)

        # Update game mode
        position.current_mode = self.determine_game_mode(state, position)

        gain_multiple = current_price / avg_cost

        # ═══════════════════════════════════════
        # PROFITABLE EXITS (House Money System)
        # ═══════════════════════════════════════

        if not position.capital_recovered:
            # ─── CAPITAL RECOVERY: sell 40% at 1.75x ───
            if gain_multiple >= TIER_CAPITAL_RECOVERY_MULT:
                shares_to_sell = int(position.shares_remaining * TIER_CAPITAL_RECOVERY_SELL_PCT)
                shares_to_sell = max(1, shares_to_sell)
                return {
                    "action": "SELL_PARTIAL",
                    "shares": shares_to_sell,
                    "price_cents": current_price,
                    "reason": f"Capital recovery: {gain_multiple:.1f}x (sell {TIER_CAPITAL_RECOVERY_SELL_PCT:.0%})",
                    "mark_capital_recovered": True,
                }
        else:
            # Capital already recovered — house money mode

            # ─── HOUSE MONEY 1: sell 25% at 3x ───
            if gain_multiple >= TIER_HOUSE_MONEY_1_MULT and not position.house_money_1_hit:
                shares_to_sell = int(position.shares_remaining * TIER_HOUSE_MONEY_1_SELL_PCT)
                shares_to_sell = max(1, shares_to_sell)
                return {
                    "action": "SELL_PARTIAL",
                    "shares": shares_to_sell,
                    "price_cents": current_price,
                    "reason": f"House money 1: {gain_multiple:.1f}x",
                    "mark_house_money_1": True,
                }

            # ─── HOUSE MONEY 2: sell 30% at 5x ───
            if gain_multiple >= TIER_HOUSE_MONEY_2_MULT and not position.house_money_2_hit:
                shares_to_sell = int(position.shares_remaining * TIER_HOUSE_MONEY_2_SELL_PCT)
                shares_to_sell = max(1, shares_to_sell)
                return {
                    "action": "SELL_PARTIAL",
                    "shares": shares_to_sell,
                    "price_cents": current_price,
                    "reason": f"House money 2: {gain_multiple:.1f}x",
                    "mark_house_money_2": True,
                }

            # ─── LATE GAME LOCK: sell 60% at 80¢+ with < 3 min left ───
            if (current_price >= TIER_LATE_GAME_PRICE_CENTS and
                    state.quarter == 4 and
                    state.time_remaining_seconds < 180):
                shares_to_sell = int(position.shares_remaining * TIER_LATE_GAME_SELL_PCT)
                shares_to_sell = max(1, shares_to_sell)
                return {
                    "action": "SELL_PARTIAL",
                    "shares": shares_to_sell,
                    "price_cents": current_price,
                    "reason": f"Late game lock: {current_price}¢ with {state.time_remaining_seconds}s left",
                }

            # ─── TRAILING STOP: 50% from peak ───
            if position.highest_price_cents > 0:
                drop_from_peak = (position.highest_price_cents - current_price) / position.highest_price_cents
                if drop_from_peak >= TIER_TRAILING_STOP_PCT:
                    return {
                        "action": "SELL_ALL",
                        "shares": position.shares_remaining,
                        "price_cents": current_price,
                        "reason": (
                            f"Trailing stop: {drop_from_peak:.0%} from peak of "
                            f"{position.highest_price_cents}¢"
                        ),
                    }

        # ═══════════════════════════════════════
        # LOSING EXITS (Mode-Based)
        # ═══════════════════════════════════════

        # OFFENSIVE MODE (Q1-Q2): NO stop losses except injury (handled externally)
        if position.current_mode == GameMode.OFFENSIVE:
            return None

        # NEUTRAL MODE (early Q3): Hold and watch
        if position.current_mode == GameMode.NEUTRAL:
            # No exits in neutral mode — we're watching the halftime adjustment
            return None

        # DEFENSIVE MODE (late Q3, Q4 when underwater):
        if position.current_mode == GameMode.DEFENSIVE:
            return_pct = position.current_return_pct(current_price)

            # ─── HARD FLOOR: value < 15% of invested in Q4 ───
            if state.quarter >= 4:
                total_value = position.current_value_cents(current_price)
                if total_value < position.total_cost_cents * TIER_DEFENSIVE_HARD_FLOOR_PCT:
                    return {
                        "action": "SELL_ALL",
                        "shares": position.shares_remaining,
                        "price_cents": current_price,
                        "reason": (
                            f"Hard floor: value {total_value}¢ < {TIER_DEFENSIVE_HARD_FLOOR_PCT:.0%} "
                            f"of invested {position.total_cost_cents}¢"
                        ),
                    }

            # ─── SELL INTO STRENGTH ───
            # If we detect positive momentum (price uptick), sell into it
            # Check if price has increased from recent low
            if (position.highest_price_cents > 0 and
                    current_price > position.avg_cost_cents * 0.5 and
                    state.momentum_score > 0.3):
                # Our team is making a mini-run — sell into this strength
                return {
                    "action": "SELL_ALL",
                    "shares": position.shares_remaining,
                    "price_cents": current_price,
                    "reason": (
                        f"Defensive exit: selling into strength at {current_price}¢ "
                        f"(momentum={state.momentum_score:.2f})"
                    ),
                }

        return None

    def update_bankroll(self, new_bankroll_cents: int):
        """Update bankroll for position sizing."""
        self.bankroll_cents = new_bankroll_cents
